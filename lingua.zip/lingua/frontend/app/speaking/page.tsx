"use client";
import { useState } from "react";
import { api } from "@/lib/api";

const SENTENCES = ["Thank you for helping me with my homework.", "The weather is rather thick today.", "I would like a cup of coffee, please."];

export default function Speaking() {
  const [target, setTarget] = useState(SENTENCES[0]);
  const [res, setRes] = useState<any>(null);
  const [listening, setListening] = useState(false);

  const record = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return alert("Please use Chrome or Edge for speech recognition.");
    const rec = new SR(); rec.lang = "en-US"; rec.maxAlternatives = 1;
    rec.onstart = () => setListening(true);
    rec.onend = () => setListening(false);
    rec.onresult = async (e: any) => {
      const { transcript, confidence } = e.results[0][0];
      setRes(await api("/ai/pronunciation", { method: "POST", body: JSON.stringify({ target, transcript, confidence }) }));
    };
    rec.start();
  };
  return (
    <div className="max-w-2xl space-y-4">
      <h1 className="text-2xl font-bold">Pronunciation practice</h1>
      <select value={target} onChange={(e) => { setTarget(e.target.value); setRes(null); }} className="border rounded px-2 py-1 w-full">
        {SENTENCES.map((s) => <option key={s}>{s}</option>)}
      </select>
      <p className="text-xl">{target}</p>
      <button onClick={record} className="btn bg-sun">{listening ? "Listening…" : "Record and check"}</button>
      {res && (
        <div className="bg-white rounded-lg p-4 space-y-2">
          <p className="text-3xl font-bold">{res.score}/100</p>
          <p>{res.words.map((w: any, i: number) => <span key={i} className={w.ok ? "text-mint" : "text-red-600 underline"}>{w.word} </span>)}</p>
          {res.tips.map((t: any, i: number) => <p key={i}><b>{t.word}:</b> {t.tip}</p>)}
        </div>
      )}
    </div>
  );
}
