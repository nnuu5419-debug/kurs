"use client";
import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import DailyIframe from "@daily-co/daily-js";
import { api } from "@/lib/api";

export default function Live() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const box = useRef<HTMLDivElement>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    let frame: ReturnType<typeof DailyIframe.createFrame> | undefined;
    api(`/video/room/${slug}`, { method: "POST" })
      .then(({ url }) => {
        frame = DailyIframe.createFrame(box.current!, { iframeStyle: { width: "100%", height: "100%", border: "0" }, showLeaveButton: true });
        frame.join({ url });
      })
      .catch((e) => (e.status === 402 ? router.replace(`/pay/${slug}`) : setErr("Could not start the class.")));
    return () => { frame?.destroy(); };
  }, [slug, router]);
  return err ? <p>{err}</p> : <div ref={box} className="h-[75vh] rounded-xl overflow-hidden bg-black" />;
}
