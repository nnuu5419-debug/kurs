"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, money } from "@/lib/api";
import { useUser } from "@/components/Auth";

type Level = { slug: string; title: string; price_cents: number; currency: string; unlocked: boolean };

export default function Home() {
  const [levels, setLevels] = useState<Level[]>([]);
  const router = useRouter();
  const { user } = useUser();
  useEffect(() => { api("/levels").then(setLevels); }, []);   // always fresh => admin price changes show instantly

  return (
    <>
      <h1 className="text-3xl font-bold mb-2">Choose your level</h1>
      {user?.level_estimate
        ? <p className="mb-6">Your test result: <b>{user.level_estimate}</b></p>
        : <p className="mb-6">Not sure? <a className="underline" href="/placement">Take the 5-minute level test.</a></p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {levels.map((l) => (
          <button key={l.slug}
            onClick={() => router.push(l.unlocked ? `/level/${l.slug}` : `/pay/${l.slug}`)}
            className="btn text-left bg-white p-6 shadow-sm hover:shadow-md">
            <span className="block text-xl">{l.title}</span>
            <span className={`block mt-2 text-sm ${l.unlocked ? "text-mint" : "text-ink/70"}`}>
              {l.unlocked ? (l.price_cents === 0 ? "Free – open" : "Purchased – open") : `Unlock for ${money(l.price_cents, l.currency)}`}
            </span>
          </button>
        ))}
      </div>
    </>
  );
}
