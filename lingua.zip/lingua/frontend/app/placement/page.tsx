"use client";
import { useState } from "react";
import { api } from "@/lib/api";

export default function Placement() {
  const [test, setTest] = useState<{ token: string; questions: { q: string; options: string[] }[] } | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [result, setResult] = useState<{ cefr: string; level: string } | null>(null);

  if (result) return <p className="text-xl">Your level: <b>{result.cefr}</b> – start with <a className="underline" href={`/level/${result.level}`}>{result.level}</a>.</p>;
  if (!test) return <button className="btn bg-ink text-white" onClick={async () => setTest(await api("/ai/placement/start", { method: "POST" }))}>Start level test</button>;

  const finish = async () => setResult(await api("/ai/placement/submit", { method: "POST", body: JSON.stringify({ token: test.token, answers }) }));
  return (
    <div className="space-y-5 max-w-2xl">
      {test.questions.map((q, i) => (
        <fieldset key={i} className="bg-white rounded-lg p-4">
          <legend className="font-semibold">{i + 1}. {q.q}</legend>
          {q.options.map((o, k) => (
            <label key={k} className="block"><input type="radio" name={`q${i}`} onChange={() => setAnswers((a) => { const n = [...a]; n[i] = k; return n; })} /> {o}</label>
          ))}
        </fieldset>
      ))}
      <button disabled={Array.from(answers).filter((x) => x !== undefined).length < test.questions.length} onClick={finish} className="btn bg-ink text-white disabled:opacity-40">See my level</button>
    </div>
  );
}
