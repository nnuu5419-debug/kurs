"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { api } from "@/lib/api";

export default function LevelPage() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  useEffect(() => {
    api(`/levels/${slug}/content`).then(setData).catch((e) => e.status === 402 && router.replace(`/pay/${slug}`));
  }, [slug, router]);
  if (!data) return <p>Loading…</p>;
  return (
    <>
      <h1 className="text-3xl font-bold mb-4">{data.title}</h1>
      <Link href={`/live/${slug}`} className="btn bg-sun inline-block mb-6">Join live class</Link>
      <ul className="space-y-3">
        {data.lessons.map((l: any, i: number) => (
          <li key={i} className="bg-white rounded-lg p-4"><h2 className="font-semibold">{l.title}</h2><p>{l.body}</p></li>
        ))}
      </ul>
    </>
  );
}
