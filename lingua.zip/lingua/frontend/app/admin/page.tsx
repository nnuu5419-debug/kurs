"use client";
import { useEffect, useState } from "react";
import { api, money } from "@/lib/api";

export default function Admin() {
  const [rows, setRows] = useState<any[] | null>(null);
  const [denied, setDenied] = useState(false);
  const [msg, setMsg] = useState("");
  useEffect(() => { api("/admin/levels").then(setRows).catch((e) => e.status === 403 && setDenied(true)); }, []);
  if (denied) return <h1 className="text-2xl font-bold">403 – Forbidden</h1>;
  if (!rows) return <p>Loading…</p>;
  const save = async (slug: string, dollars: string) => {
    try {
      await api(`/admin/levels/${slug}`, { method: "PATCH", body: JSON.stringify({ price_cents: Math.round(parseFloat(dollars) * 100) }) });
      setMsg(`Saved ${slug}. The new price is live now.`);
    } catch { setMsg("Could not save that price."); }
  };
  return (
    <>
      <h1 className="text-2xl font-bold mb-4">Course prices</h1>
      <div className="space-y-3">
        {rows.map((r) => (
          <form key={r.slug} onSubmit={(e) => { e.preventDefault(); save(r.slug, (e.currentTarget.elements.namedItem("p") as HTMLInputElement).value); }}
                className="bg-white rounded-lg p-4 flex items-center gap-4">
            <span className="w-48 font-semibold">{r.title}</span>
            <input name="p" type="number" step="0.01" min="0" defaultValue={r.price_cents / 100} disabled={r.slug === "beginner"}
                   className="border rounded px-2 py-1 w-28" aria-label={`${r.title} price`} />
            <span className="text-sm text-ink/60">now {money(r.price_cents, r.currency)}</span>
            {r.slug !== "beginner" && <button className="btn bg-ink text-white ml-auto">Save price</button>}
          </form>
        ))}
      </div>
      <p role="status" className="mt-4 text-mint">{msg}</p>
    </>
  );
}
