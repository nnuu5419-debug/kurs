"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { api, money } from "@/lib/api";

export default function Pay() {
  const { slug } = useParams<{ slug: string }>();
  const [level, setLevel] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { api("/levels").then((ls) => setLevel(ls.find((l: any) => l.slug === slug))); }, [slug]);
  if (!level) return <p>Loading…</p>;
  const go = async () => {
    setBusy(true);
    const { url } = await api("/payments/checkout", { method: "POST", body: JSON.stringify({ level_slug: slug }) });
    window.location.href = url;   // Stripe-hosted payment page
  };
  return (
    <div className="max-w-md bg-white rounded-xl p-8 space-y-4">
      <h1 className="text-2xl font-bold">{level.title} is locked</h1>
      <p>Pay once to unlock all lessons, live classes and AI practice for this level.</p>
      <p className="text-3xl font-bold">{money(level.price_cents, level.currency)}</p>
      <button disabled={busy} onClick={go} className="btn bg-ink text-white w-full">{busy ? "Opening payment…" : "Pay and unlock"}</button>
    </div>
  );
}
